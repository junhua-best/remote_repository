The proofs in the subdirectories show that
ARPProcessPacket is memory safe independent
of the configuration value of
ipconfigARP_USE_CLASH_DETECTION.