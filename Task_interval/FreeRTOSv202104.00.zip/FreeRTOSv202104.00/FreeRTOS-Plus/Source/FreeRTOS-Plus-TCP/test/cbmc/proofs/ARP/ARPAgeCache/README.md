Assuming that xNetworkInterfaceOutput is memory safe,
this harness proves the memory safety of the vARPAgeCache function.
